function validate() 
{
	var firstname = document.getElementById("fname");
	var lastname = document.getElementById("lname");
	var email_id = document.getElementById("email");

	if (firstname.value=="" || lastname.value=="")
	{  
    alert("Name can't be blank");  
    return false;  
    }
    else if(email_id.value==""  )
    {  
    alert("check email_id ");  
    return false;  
    }  
 } 

